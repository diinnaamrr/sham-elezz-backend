<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DriveMondController extends Controller
{
    public function drivemondExternalLogin()
    {
        // Dummy implementation
        return redirect()->route('admin.dashboard');
    }
}
